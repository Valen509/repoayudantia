package cl.valep.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {
    Button btnqr, button;
    FirebaseAuth auth;
    FirebaseUser user;
    TextView tv2, textView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView texto = (TextView) findViewById(R.id.tv1);
        texto.setText("Bienvenid@");

        //Proceso de escaner de código QR
        btnqr = findViewById(R.id.btnqr);
        tv2 = findViewById(R.id.tv2);

        Button btnqr = (Button) findViewById(R.id.btnqr);
        btnqr.setOnClickListener(view -> {
            IntentIntegrator integrador = new IntentIntegrator(MainActivity.this);
            integrador.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            integrador.setPrompt("Lector - QR");
            integrador.setCameraId(0);
            integrador.setBeepEnabled(false);
            integrador.setBarcodeImageEnabled(true);
            integrador.initiateScan();
        });

        auth = FirebaseAuth.getInstance();
        button = findViewById(R.id.btnlogout);
        textView = findViewById(R.id.user_details);
        user = auth.getCurrentUser();
        if (user == null){
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finish();
        }else{
            textView.setText(user.getEmail());
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }

    //Resultados del escaner de código QR (Método)
    @SuppressLint("SetTextI18n")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null){
            if(result.getContents()==null){
                Toast.makeText(this, "Lectura cancelada", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                tv2.setText("Este código QR pertenece a: "+result.getContents());
            }

        }else{
            super.onActivityResult(requestCode, resultCode, data);
        }

    }

    public void irCarrito(View vista){
        Intent intent = new Intent(this, CrudCarrito.class);
        startActivity(intent);
    }








}