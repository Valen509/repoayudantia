package cl.valep.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    HomeFragment homeFragment = new HomeFragment();
    QrCodeScanFragment qrCodeScanFragment = new QrCodeScanFragment();
    ShoppingCartFragment shoppingCartFragment = new ShoppingCartFragment();
    UserProfileFragment userProfileFragment = new UserProfileFragment();

    Button btnqr;
    TextView tv2;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Mini menú de navegación entre pantallas
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();
                        return true;
                    case R.id.qr_scanner:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,qrCodeScanFragment).commit();
                        return true;
                    case R.id.shopping_cart:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,shoppingCartFragment).commit();
                        return true;
                    case R.id.user:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,userProfileFragment).commit();
                        return true;
                }
                return false;
            }
        });//No cambia entre pantallas (cambia entre fragmentos, no actividades), solo se mantiene en la pantalla principal


        TextView texto = (TextView) findViewById(R.id.tv1);
        texto.setText("Bienvenid@");

        //Proceso de escaner de código QR
        btnqr = findViewById(R.id.btnqr);
        tv2 = findViewById(R.id.tv2);

        Button btnqr = (Button) findViewById(R.id.btnqr);
        btnqr.setOnClickListener(view -> {
            IntentIntegrator integrador = new IntentIntegrator(MainActivity.this);
            integrador.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            integrador.setPrompt("Lector - QR");
            integrador.setCameraId(0);
            integrador.setBeepEnabled(false);
            integrador.setBarcodeImageEnabled(true);
            integrador.initiateScan();
        });
    }

    //Resultados del escaner de código QR (Método)
    @SuppressLint("SetTextI18n")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null){
            if(result.getContents()==null){
                Toast.makeText(this, "Lectura cancelada", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                tv2.setText("Este código QR pertenece a: "+result.getContents());
            }

        }else{
            super.onActivityResult(requestCode, resultCode, data);
        }

    }

    public void irCarrito(View vista){
        Intent intent = new Intent(this, CrudCarrito.class);
        startActivity(intent);
    }





}