package cl.valep.myapplication.Models;

public class Producto {

    private String idproducto;
    private String producto;
    private int cantidad;
    private double precio;
    private String fecharegistro;
    private long timestamp;

    public Producto(String producto, double precio, int cantidad) {
        this.producto = producto;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public Producto() {

    }


    public String getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(String idproducto) {
        this.idproducto = idproducto;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getCantidad() { return cantidad; }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio() {
        return (int) precio;
    }

    public void setPrecio(String precio) {
        this.precio = (int) Float.parseFloat(precio);
    }

    public String getFecharegistro() {
        return fecharegistro;
    }

    public void setFecharegistro(String fecharegistro) {
        this.fecharegistro = fecharegistro;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }



    @Override
    public String toString() {
        return producto;
    }

    public double calcularSubtotal(){
        return this.precio * this.cantidad;
    }

    /*public float calcularSubtotal(){
        float subtotal = 0;
        for(Producto producto : productos){
            subtotal += producto.calcularPrecioTotal();
        }
        return subtotal;
    }
     */



}

