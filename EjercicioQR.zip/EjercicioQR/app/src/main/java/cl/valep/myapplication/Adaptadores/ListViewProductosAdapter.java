package cl.valep.myapplication.Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import cl.valep.myapplication.Models.Producto;
import cl.valep.myapplication.R;

public class ListViewProductosAdapter extends BaseAdapter {
    Context context;
    ArrayList<Producto> productoData;
    LayoutInflater layoutInflater;
    Producto productoModel;

    public ListViewProductosAdapter(Context context, ArrayList<Producto> productoData) {
        this.context = context;
        this.productoData = productoData;
        layoutInflater = (LayoutInflater) context.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE
        );
    }

    @Override
    public int getCount() {
        return productoData.size();
    }

    @Override
    public Object getItem(int position) {
        return productoData.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;
        if(rowView==null){
            rowView = layoutInflater.inflate(R.layout.lista_productos,
                    null,
                    true);
        }
        //enlazar vistas
        TextView producto = rowView.findViewById(R.id.producto);
        TextView precio = rowView.findViewById(R.id.precio);
        TextView fecharegistro = rowView.findViewById(R.id.fecharegistro);

        productoModel = productoData.get(position);
        producto.setText(productoModel.getProducto());
        precio.setText(Integer.toString(productoModel.getPrecio()));
        fecharegistro.setText(productoModel.getFecharegistro());

        return rowView;
    }
}
