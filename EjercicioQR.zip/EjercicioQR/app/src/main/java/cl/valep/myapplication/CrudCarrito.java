package cl.valep.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.UUID;

import cl.valep.myapplication.Adaptadores.ListViewProductosAdapter;
import cl.valep.myapplication.Models.Producto;

public class CrudCarrito extends AppCompatActivity {

    private ArrayList<Producto> listProductos= new ArrayList<>();
    ArrayAdapter<Producto> arrayAdapterProducto;
    ListViewProductosAdapter listViewProductosAdapter;
    LinearLayout linearLayoutEditar;
    ListView listViewProductos;

    EditText inputProducto, inputPrecio;
    Button btnCancelar;

    Producto productoSeleccionado;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud_carrito);

        inputProducto = findViewById(R.id.inputProducto);
        inputPrecio = findViewById(R.id.inputPrecio);
        btnCancelar = findViewById(R.id.btnCancelar);

        listViewProductos = findViewById(R.id.listViewProductos);
        linearLayoutEditar = findViewById(R.id.linearLayoutEditar);

        listViewProductos.setOnItemClickListener((parent, view, position, l) -> {
            productoSeleccionado = (Producto) parent.getItemAtPosition(position);
            inputProducto.setText(productoSeleccionado.getProducto());
            inputPrecio.setText(productoSeleccionado.getPrecio());

            //hacer visible el LinearLayout
            linearLayoutEditar.setVisibility(View.VISIBLE);

        });

        // Boton cancelar, ocultar el layout
        btnCancelar.setOnClickListener(v -> {
            linearLayoutEditar.setVisibility(View.GONE);
            productoSeleccionado = null;
        });

        inicializarFirebase();
        listarProductos();
    }


    //Conexion a Firebase
    private void inicializarFirebase(){
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

    }

    private void listarProductos(){
        databaseReference.child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listProductos.clear();
                for(DataSnapshot objSnapshot : dataSnapshot.getChildren()) {
                    Producto p = objSnapshot.getValue(Producto.class);
                    listProductos.add(p);
                }
                // iniciar adaptador simple
                listViewProductosAdapter = new ListViewProductosAdapter(CrudCarrito.this, listProductos);
                /*arrayAdapterProducto = new ArrayAdapter<Producto>(
                        CrudCarrito.this,
                        android.R.layout.simple_list_item_1,
                        listProductos
                );
                */
                listViewProductos.setAdapter(listViewProductosAdapter);
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.crud_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String productos = inputProducto.getText().toString();
        String precio = inputPrecio.getText().toString();
        switch (item.getItemId()){
            case R.id.menu_agregar:
                insertar();
                break;
            case R.id.menu_guardar:
                if(productoSeleccionado != null){
                    if(!validarInputs()){
                        Producto p = new Producto();
                        p.setIdproducto(productoSeleccionado.getIdproducto());
                        p.setProducto(productos);
                        p.setPrecio(precio);
                        p.setFecharegistro(productoSeleccionado.getFecharegistro()); // fecha en formato humano actualizada
                        p.setTimestamp(productoSeleccionado.getTimestamp()); // fecha en formato UNIX actualizada
                        databaseReference.child("Productos").child(p.getIdproducto()).setValue(p);
                        Toast.makeText(this, "Actualizado con éxito", Toast.LENGTH_LONG).show();
                        linearLayoutEditar.setVisibility(View.GONE);
                        productoSeleccionado = null;
                    }else{
                        Toast.makeText(this, "Seleccione un producto", Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.menu_eliminar:
                if(productoSeleccionado != null) {
                    Producto p2 = new Producto();
                    p2.setIdproducto(productoSeleccionado.getIdproducto());
                    databaseReference.child("Productos").child(p2.getIdproducto()).removeValue();
                    linearLayoutEditar.setVisibility(View.GONE);
                    productoSeleccionado = null;
                    Toast.makeText(this, "Producto eliminado con éxito", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(this, "Seleccione un producto para eliminar", Toast.LENGTH_LONG).show();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void insertar(){
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(
                CrudCarrito.this);
        View mView = getLayoutInflater().inflate(R.layout.insertar, null);
        Button btnInsertar = (Button) mView.findViewById(R.id.btnInsertar);
        final EditText mInputProducto = (EditText) mView.findViewById(R.id.inputProducto);
        final EditText mInputPrecio = (EditText) mView.findViewById(R.id.inputPrecio);

        // AlertDialog para mostrar los cuadros de texto
        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();

        btnInsertar.setOnClickListener(view -> {
            String producto = mInputProducto.getText().toString();
            String precio = mInputPrecio.getText().toString();
            if(producto.isEmpty() || producto.length()<3){
                showError(mInputProducto, "Producto inválido, mínimo 3 letras");
            }else if(precio.isEmpty() || precio.length() <3){
                showError(mInputPrecio, "Precio inválido, mínimo 3 números");
            }else{
                Producto p = new Producto();
                p.setIdproducto(UUID.randomUUID().toString());
                p.setProducto(producto);
                p.setPrecio(precio);
                p.setFecharegistro(getFechaNormal(getFechaMilisegundos()));
                p.setTimestamp(getFechaMilisegundos() * -1); // fecha UNIX en orden descendente
                databaseReference.child("Productos").child(p.getIdproducto()).setValue(p);
                Toast.makeText(
                        CrudCarrito.this,
                        "Producto registrado con éxito",
                        Toast.LENGTH_LONG).show();
                dialog.dismiss();
            }
        });
    }
    public void showError(EditText input, String s){
        input.requestFocus();
        input.setError(s);

    }

    public long getFechaMilisegundos(){
        Calendar calendar = Calendar.getInstance();

        return calendar.getTimeInMillis();
    }

    public String getFechaNormal(long fechamilisegundos){
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT-4"));
        return sdf.format(fechamilisegundos);
    }

    public boolean validarInputs(){
        String producto = inputProducto.getText().toString();
        String precio = inputPrecio.getText().toString();
        if(producto.isEmpty() || producto.length()<3){
            showError(inputProducto, "Producto inválido, mínimo 3 letras");
            return true;
        }else if(precio.isEmpty() || precio.length() <3){
            showError(inputPrecio, "Precio inválido, mínimo 3 números");
            return true;
        }else{
            return false;
        }
    }

}